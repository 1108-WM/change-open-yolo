"""Replay the two frozen reference scenes on CPU; no images, GT, or GPU inference."""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from types import SimpleNamespace

BUNDLE = Path(__file__).resolve().parent

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(4*1024**2), b''):
            h.update(b)
    return h.hexdigest()

def read(path):
    return json.loads(Path(path).read_text())

def verify_bundle():
    for name, expected in read(BUNDLE/'manifest.json')['files'].items():
        if sha(BUNDLE/name) != expected:
            raise ValueError('Supplement checksum changed: '+name)

def load_release(root):
    sys.path.insert(0, str(root))
    spec = importlib.util.spec_from_file_location('frozen_release_runner', root/'tools/run_frozen_full800.py')
    core = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(core)
    expected = read(BUNDLE/'bundle_info.json')['release_manifest_sha256']
    if sha(root/'reproduction/manifest.json') != expected:
        raise ValueError('Use the original 27b7bec runtime, with its unchanged manifest.')
    core.verify_release()
    return core

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--release-root', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    a.release_root = a.release_root.resolve()
    a.output = a.output.resolve()
    if a.output.exists():
        raise FileExistsError('Use a fresh replay output directory: '+str(a.output))
    if a.output.is_relative_to(BUNDLE) or a.output.is_relative_to(a.release_root):
        raise ValueError('Keep replay output outside the immutable release and reference bundle.')
    verify_bundle()
    core = load_release(a.release_root)
    import numpy as np
    checks = []
    scenes = read(BUNDLE/'bundle_info.json')['scenes']
    for scene, spec in scenes.items():
        folder = BUNDLE/'scenes'/scene
        out = a.output/'predictions'/scene
        core.score(SimpleNamespace(scenes=[scene], point_count=None,
            geometry_dir=folder/'geometry_binding',
            evidence_file=folder/'alpha_completed'/scene/'evidence.jsonl',
            semantic_provenance=None, output=out))
        selected = read(out/'selected.json')
        # Compare all fields, scores, and order, not merely object IDs.
        if selected != read(folder/'historical/full_selected.json'):
            raise AssertionError(scene+': historical K800 members differ')
        with np.load(out/'features_scores.npz', allow_pickle=False) as got, np.load(
                folder/'release_reference/features_scores.npz', allow_pickle=False) as expected:
            for key in ['X26', 'scores']:
                if not np.array_equal(got[key], expected[key]):
                    raise AssertionError(scene+': '+key+' differs from the original release replay')
            if not np.array_equal(got['scores'], np.load(folder/'historical/full_scores.npy', allow_pickle=False)):
                raise AssertionError(scene+': historical B26 scores differ')
            count = len(got['scores'])
        with np.load(out/'selected_points.npz', allow_pickle=False) as got, np.load(
                folder/'release_reference/selected_points.npz', allow_pickle=False) as expected:
            if set(got.files) != set(expected.files) or any(not np.array_equal(got[k], expected[k]) for k in got.files):
                raise AssertionError(scene+': selected pointsets differ')
        if len(selected) != 800 or count != spec['members']:
            raise AssertionError(scene+': expected member counts differ')
        checks.append({'scene':scene, 'X26_rows':count, 'selected':len(selected),
                       'all_features_scores_members_points_exact':True,
                       'selected_sha256':sha(out/'selected.json')})
    core.seal(SimpleNamespace(scenes=list(scenes), predictions_root=a.output/'predictions'))
    report={'complete':True, 'checks':checks, 'total_selected':sum(c['selected'] for c in checks),
            'GT_read':False, 'new_training':False, 'new_GPU_inference':False, 'new_AP':False}
    (a.output/'verification.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()
