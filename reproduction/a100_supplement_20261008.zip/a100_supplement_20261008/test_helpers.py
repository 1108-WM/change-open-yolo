import json
from pathlib import Path
import tempfile
import unittest

from audit_frontend import audit, digest, sha
from run_with_split_visual_envs import select_python

class Helpers(unittest.TestCase):
    def test_native_routing_including_dense_observations(self):
        for tool,argv in [('run_frozen_full800.py',['native']),('export_sam_automatic_observations.py',[]),('export_dense_frame_instance_observations.py',[])]:
            self.assertEqual(select_python(tool,argv,'native','semantic','original'),'native')

    def test_semantic_routing(self):
        for tool,argv in [('run_frozen_full800.py',['frontend']),('run_frozen_full800.py',['alpha']),
                         ('build_details_same_frame_hierarchy_preprocessor.py',[]),
                         ('export_fi1_r0_r1_yolo_views.py',[])]:
            self.assertEqual(select_python(tool,argv,'native','semantic','original'),'semantic')

    def test_geometry_and_backend_unchanged(self):
        for tool,argv in [('evaluate_fi1_frontend_comparison.py',['full-geometry']),
                         ('evaluate_fi1_frontend_comparison.py',['full-bind']),
                         ('run_frozen_full800.py',['score'])]:
            self.assertEqual(select_python(tool,argv,'native','semantic','original'),'original')

    def test_unknown_assets_schema_rejected_without_writing(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); file=root/'contract.json'; file.write_text(json.dumps({'assets':[]}))
            before=file.read_bytes()
            result=audit(root,'scene0354_00',root,root)
            self.assertFalse(result['release_contract_checks_passed'])
            self.assertTrue(result['errors'])
            self.assertEqual(file.read_bytes(),before)
            self.assertEqual([p.name for p in root.iterdir()],['contract.json'])

    def make_cache(self,root):
        release=root/'release'; front=root/'front'; dataset=root/'data'; scene='scene0354_00'
        def write(p,v):
            p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(v))
        names=['run_fi1_frontend_comparison.py','fi1_frontend_protocol.py',
               'build_details_same_frame_hierarchy_preprocessor.py','build_details_frame_siou_tracks.py',
               'refine_details_automatic_tracks_consensus.py','build_details_iterative_proposal_merges.py']
        assets={}
        for name in names:
            file=release/'tools'/name;file.parent.mkdir(parents=True,exist_ok=True);file.write_text(name)
            assets['/historical/tools/'+name]=sha(file)
        weights={k:{'sha256':k} for k in ['sam_checkpoint','groundingdino']}
        write(release/'reproduction/external_weights.json',weights)
        assets.update({k:v['sha256'] for k,v in weights.items()})
        contract={'assets':assets};write(front/'contract.json',contract)
        processed=dataset/scene/'0354_00.npy';processed.parent.mkdir(parents=True);processed.write_bytes(b'points')
        manifest={'scene_name':scene,'original_frame_count':21,'arms':{'D':[0,10,20]},
                  'files':{'processed':{'path':str(processed),'sha256':sha(processed)}}}
        write(front/'manifests'/f'{scene}.json',manifest)
        identity=digest({'contract':digest(contract),'manifest':digest(manifest),'frontend':'grounded_sam','arm':'D'})
        for stage in ['hierarchy','tracks','consensus','merged']:
            file=front/'arms/D'/stage/scene/'example.json';file.parent.mkdir(parents=True,exist_ok=True);file.write_text(stage)
            write(front/'arms/D/stage_receipts'/f'{scene}_{stage}.json',{'identity':identity,'files':{'example.json':sha(file)}})
        return release,front,dataset,scene

    def test_known_contract_and_bytes(self):
        with tempfile.TemporaryDirectory() as tmp:
            release,front,dataset,scene=self.make_cache(Path(tmp))
            self.assertTrue(audit(front,scene,dataset,release)['release_contract_checks_passed'])

    def test_changed_stage_bytes_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            release,front,dataset,scene=self.make_cache(Path(tmp))
            (front/'arms/D/merged'/scene/'example.json').write_text('changed')
            self.assertFalse(audit(front,scene,dataset,release)['release_contract_checks_passed'])

    def test_relocated_data_diagnosed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);release,front,dataset,scene=self.make_cache(root)
            new=root/'relocated';file=new/scene/'0354_00.npy';file.parent.mkdir(parents=True);file.write_bytes(b'points')
            result=audit(front,scene,new,release)
            checks={r['check']:r['ok'] for r in result['checks']}
            self.assertFalse(checks['dataset_root'])
            self.assertTrue(checks['current_processed_bytes'])
            self.assertFalse(result['release_contract_checks_passed'])

if __name__=='__main__': unittest.main()
