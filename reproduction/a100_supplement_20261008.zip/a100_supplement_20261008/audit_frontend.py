"""Read-only audit of a GD10 cache against the original release input contract.

This emits reasons for rejection. It does not convert, sign, approve, or overwrite a cache.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

def read(p):
    return json.loads(p.read_text())

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(4*1024**2),b''):
            h.update(b)
    return h.hexdigest()

def digest(v):
    return hashlib.sha256(json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()).hexdigest()

def audit(front, scene, dataset, release):
    report={'scene':scene,'frontend_root':str(front),'checks':[], 'errors':[],
            'cache_modified':False,'GT_read':False,'new_GPU_inference':False,
            'release_contract_checks_passed':False}
    def check(name, ok, detail):
        report['checks'].append({'check':name,'ok':bool(ok),'detail':detail})
        if not ok: report['errors'].append(name+': '+str(detail))
    try:
        contract=read(front/'contract.json')
        check('contract_object',isinstance(contract,dict),'top-level must be a JSON object')
        if not isinstance(contract,dict): return report
        report['contract_fields']=sorted(contract)
        assets=contract.get('assets')
        check('assets_mapping',isinstance(assets,dict),'expected assets: {original_file_path: sha256}')
        if not isinstance(assets,dict): return report
        weights=read(release/'reproduction/external_weights.json')
        for name in ['sam_checkpoint','groundingdino']:
            check(name+'_identity',weights[name]['sha256'] in assets.values(),weights[name]['sha256'])
        for name in ['run_fi1_frontend_comparison.py','fi1_frontend_protocol.py',
                     'build_details_same_frame_hierarchy_preprocessor.py','build_details_frame_siou_tracks.py',
                     'refine_details_automatic_tracks_consensus.py','build_details_iterative_proposal_merges.py']:
            hashes=[h for p,h in assets.items() if p.endswith('/tools/'+name)]
            check('kernel:'+name,hashes==[sha(release/'tools'/name)],{'recorded':hashes,'expected':sha(release/'tools'/name)})
        manifest=read(front/'manifests'/f'{scene}.json')
        report['manifest_fields']=sorted(manifest)
        check('scene',manifest['scene_name']==scene,manifest['scene_name'])
        expected=list(range(0,manifest['original_frame_count'],10))
        check('raw_stride10',manifest['arms']['D']==expected,{'expected_frames':len(expected),'recorded_frames':len(manifest['arms']['D'])})
        recorded=Path(manifest['files']['processed']['path'])
        check('dataset_root',recorded.parent.parent.resolve()==dataset.resolve(),{'recorded':str(recorded),'requested':str(dataset)})
        # A relocated byte-identical dataset is reported separately. Original receipts remain unchanged.
        new=dataset/scene/(scene[5:]+'.npy')
        check('current_processed_bytes',new.is_file() and sha(new)==manifest['files']['processed']['sha256'],str(new))
        identity=digest({'contract':digest(contract),'manifest':digest(manifest),'frontend':'grounded_sam','arm':'D'})
        for stage in ['hierarchy','tracks','consensus','merged']:
            receipt=read(front/'arms/D/stage_receipts'/f'{scene}_{stage}.json')
            check(stage+'_identity',receipt['identity']==identity,{'recorded':receipt['identity'],'expected':identity})
            for name,h in receipt['files'].items():
                file=front/'arms/D'/stage/scene/name
                check(stage+':'+name,file.is_file() and sha(file)==h,str(file))
    except (KeyError,TypeError,ValueError,OSError) as e:
        report['errors'].append(type(e).__name__+': '+str(e))
    report['release_contract_checks_passed']=not report['errors']
    report['note']='This diagnostic covers frontend contract checks; full geometry also validates RGB-D hashes, point ordering and lineage. A different schema needs audited mapping; no validator bypass.'
    return report

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--release-root',type=Path,required=True)
    p.add_argument('--frontend-root',type=Path,required=True)
    p.add_argument('--dataset-root',type=Path,required=True)
    p.add_argument('--scene',required=True)
    a=p.parse_args()
    print(json.dumps(audit(a.frontend_root.resolve(),a.scene,a.dataset_root.resolve(),a.release_root.resolve()),ensure_ascii=False,indent=2))

if __name__=='__main__': main()
