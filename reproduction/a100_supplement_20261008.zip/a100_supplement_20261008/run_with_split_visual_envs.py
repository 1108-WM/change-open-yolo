"""Route original frozen GPU stages to separate native and semantic environments.

The frozen 27b7bec runner, thresholds, models and cache validator remain unchanged.
The new routing has CPU unit coverage only; A100 end-to-end inference is not yet tested.
"""
from __future__ import annotations
import argparse
from pathlib import Path
from types import SimpleNamespace
from replay_reference import load_release, verify_bundle

def select_python(tool, argv, native, semantic, original):
    if tool=='run_frozen_full800.py' and argv and argv[0] in ('frontend','alpha'):
        return semantic
    if tool in {'build_details_same_frame_hierarchy_preprocessor.py',
                'export_fi1_r0_r1_yolo_views.py'}:
        return semantic
    # export_dense_frame_instance_observations initializes OpenYolo3D, so it needs native dependencies.
    if tool in {'export_sam_automatic_observations.py','export_dense_frame_instance_observations.py'} or (tool=='run_frozen_full800.py' and argv and argv[0]=='native'):
        return native
    return original

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ['release-root','dataset-root','output','native-python','semantic-python','geometry-python','backend-python']:
        p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--frontend-root',type=Path)
    p.add_argument('--scenes',nargs='+',default=['scene0549_00'])
    p.add_argument('--all-scenes',action='store_true')
    p.add_argument('--print-routing',action='store_true')
    a=p.parse_args()
    verify_bundle()
    core=load_release(a.release_root.resolve())
    if a.print_routing:
        for tool,argv,original in [('run_frozen_full800.py',['native'],a.native_python),
                ('export_sam_automatic_observations.py',[],a.native_python),
                ('export_dense_frame_instance_observations.py',[],a.native_python),
                ('run_frozen_full800.py',['frontend'],a.native_python),
                ('evaluate_fi1_frontend_comparison.py',['full-geometry'],a.geometry_python),
                ('evaluate_fi1_frontend_comparison.py',['full-bind'],a.backend_python),
                ('export_fi1_r0_r1_yolo_views.py',[],a.native_python),
                ('run_frozen_full800.py',['alpha'],a.native_python),
                ('run_frozen_full800.py',['score'],a.backend_python)]:
            print(tool,*argv,'=>',select_python(tool,argv,a.native_python,a.semantic_python,original))
        return
    if a.all_scenes: a.scenes=None
    args=SimpleNamespace(dataset_root=a.dataset_root.resolve(),output=a.output.resolve(),
        visual_python=a.native_python.absolute(),geometry_python=a.geometry_python.absolute(),
        backend_python=a.backend_python.absolute(),frontend_root=a.frontend_root.resolve() if a.frontend_root else None,
        scenes=a.scenes)
    if (args.output/'split_environment_routing.json').exists():
        raise FileExistsError('Use a fresh output directory for this supplemental routing.')
    core.write(args.output/'split_environment_routing.json',{'native_python':str(a.native_python),
        'semantic_python':str(a.semantic_python),'geometry_python':str(a.geometry_python),
        'backend_python':str(a.backend_python),'A100_full_GPU_pipeline_tested':False})
    original=core.launch
    def routed(python,tool,*argv):
        return original(select_python(tool,argv,a.native_python,a.semantic_python,python),tool,*argv)
    core.launch=routed
    core.run(args)

if __name__=='__main__': main()
